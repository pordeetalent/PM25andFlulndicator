#ifndef __GLOBAL_H
#define __GLOBAL_H

#define WLAN_SSID "SunNET"       
#define WLAN_PASS "maramara"

#endif
